from libqtile import layout
from libqtile.config import Match

layouts = [
    # layout.Columns(border_focus_stack=["#d75f5f", "#8f3d3d"], border_width=4),
    layout.RatioTile(),
    layout.Max(),
    layout.Matrix(),
]