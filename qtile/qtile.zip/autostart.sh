#!/bin/sh

## Systray Icons
nitrogen --restore &
picom &
nm-applet &